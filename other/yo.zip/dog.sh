#!/bin/bash
. /etc/profile
LOGTIME=$(date "+%Y-%m-%d %H:%M:%S")
CURRENT_DIR=$(cd $(dirname $0); pwd)
livetv_pid=$(ps -ef|grep ./livetv|grep -v grep|awk '{print $2}')

start_livetv()
    {
       ./livetv 2>&1 &
}
stop_livetv()      
    {              
       kill $livetv_pid
}

check_livetv()
    { 
           if [ ! -n "$livetv_pid" ]; then
           $CURRENT_DIR/dog.sh start_livetv
           livetv_pid_new=$(ps -ef|grep ./livetv|grep -v grep|awk '{print $2}')
           echo [$LOGTIME] Starting livetv ...
           echo [$LOGTIME] $livetv_pid_new livetv
else
        echo [$LOGTIME] $livetv_pid livetv
fi
}

check()
    {
        check_livetv
        rm -rf $CURRENT_DIR/easy-cron-log
}

INPUT=$1
if [ -z "$1" ]
then    
check
else     
case "$INPUT" in
start_livetv) start_livetv;;
stop_livetv) stop_livetv;;
check_livetv) check_livetv;;
esac
fi