# main.sh

##Easy-cron启动
# 更改Easy-cron工作目录
ecpath=$(pwd|cut -d \/ -f4)
ecconfpath=$(cat config.yaml|grep /home/runner|sed 's/.*runner\/\(.*\)/\1/g'|cut -d \/ -f1|head -n 1)
sed -i "s/$ecconfpath/$ecpath/g" config.yaml
# 赋予Easy-cron及脚本可执行权限
chmod +x easy-cron
chmod +x dog.sh
# 启动Easy-cron
./easy-cron >/dev/null 2>&1 &

##设置环境变量
home=$(pwd)
#监听端口
export LIVETV_LISTEN=0.0.0.0:9000
#数据路径
export LIVETV_DATADIR=$home/data
#默认中文
export LANG=zh_CN.UTF-8
#赋予可执行权限
chmod +x livetv

##启动程序
#建立目录
if [ ! -d $LIVETV_DATADIR ]; then
  mkdir data
fi
#启动程序
./livetv